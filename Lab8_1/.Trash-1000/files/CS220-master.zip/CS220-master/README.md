# CS220
This repository contains the verilog code for FPGA programming done in the course CS220: Computer Organization at IIT Kanpur
